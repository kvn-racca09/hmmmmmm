# Postman Evidence Checklist

Student: Kevin Christopher R. Racca  Section: TN35  Date: 2026-10-06

Status: offline validation completed; local simulator and Postman execution pending.
Submit screenshots or exported responses only after redacting credential values.
Expected results below are predictions from the supplied checker, not observed responses.

- [ ] R1: GET all books, with URL and actual 200 status visible
- [ ] R2: GET books using `includeISBN=true` and `sortBy=author`; verify ISBN inclusion and author ordering against local documentation
- [ ] R3: Basic Auth request and actual 200 status; username, password and returned token fully hidden
- [ ] R4: POST a fictional book, with JSON body and actual 200 status visible
- [ ] R5: GET the newly added book by ID; compare ID, title and author with R4
- [ ] R6: DELETE the newly added book by ID; confirm the removal using a follow-up retrieval/list
- [ ] R7: Intentional local failure showing actual 401 with key values hidden
- [ ] Final successful verification after correcting R7, followed by cleanup
- [x] Offline validator output showing all checks passed (`validator_output.txt`: 11/11)

## Capture requirements

For each scenario, record results from both the API Simulator and Postman: method, local request URL, actual status, brief response summary, and a redacted evidence filename. Keep book identifiers consistent within each run. R3 evidence must not expose the temporary token, Basic Auth fields or a generated authentication header.

| Scenario | Expected status | Simulator result / evidence | Postman result / evidence |
|---|---:|---|---|
| R1 | 200 | Pending | Pending |
| R2 | 200 | Pending | Pending |
| R3 | 200 | Pending | Pending |
| R4 | 200 | Pending | Pending |
| R5 | 200 | Pending | Pending |
| R6 | 200 | Pending | Pending |
| R7 failure | 401 | Pending | Pending |
| R7 repaired | 200 | Pending | Pending |
| R7 verification and cleanup | 200 for documented GET/DELETE success | Pending | Pending |

Run the simulator sequence and clean up before repeating in Postman, or choose different unused fictional IDs for the two runs. Confirm the payload ID type and allowed range in the local OpenAPI schema; the prepared numeric ID is an example only. Confirm an ID is unused before adding it. Do not delete a pre-existing record to make room.

Never export or submit a live Postman environment containing secrets. Use the original secret-free collection supplied here when assembling the submission. Check evidence only after actually recording the result.
