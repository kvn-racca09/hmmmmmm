# AI and API Validation Log

Student: Kevin Christopher R. Racca  Section: TN35  Date: 2026-10-06

AI tool used: ChatGPT. Instructor approval must be confirmed locally.

## Evidence status and chronology

This log records AI-assisted preparation from the supplied manual and starter files. No student pre-AI predictions or earlier AI transcript were supplied, so none are invented. The prompt column summarizes the sanitized request checks assessed during this assistance; it is not a verbatim historical student transcript. Decisions are provisional plan evaluations, not claims of live API success.

The original, unmodified offline validator was actually run and returned **11/11 checks passed**. Its evidence check only requires nonempty text; it does not verify screenshots, API behavior, payload field types, or that the student completed a pre-AI checkpoint. No local OpenAPI page, simulator responses, Postman responses, or credentials were accessed. Every live evidence item remains pending.

Sanitized prompt scope: Work only in the authorized local simulator. Do not request or generate secret values. Treat predictions as hypotheses and compare them with the local API documentation before execution. Observed runtime status/error: none supplied.

| Request | Pre-AI prediction | Sanitized AI prompt | AI recommendation | Decision (Accepted/Modified/Rejected) | Simulator/Postman evidence |
|---|---|---|---|---|---|
| R1 | Not recorded before AI. Prepared candidate: GET /api/v1/books; none; 200. | Check GET /api/v1/books, no authentication, expected 200, for listing books. | GET the collection; no body or authentication; predict 200. | Accepted for the plan: the supplied checker requires this method, path, authentication label and status. | Pending: no live execution. Offline fields checked against the supplied validator; see validator_output.txt. |
| R2 | Not recorded before AI. Prepared candidate: GET /api/v1/books; none; 200. | Check GET /api/v1/books with includeISBN=true and sortBy=author, expected 200. | Put both exact parameter names and values in the query string; predict 200. | Accepted for the plan: manual section 9 and the checker require these query values. | Pending: no live execution. Offline fields checked against the supplied validator; see validator_output.txt. |
| R3 | Not recorded before AI. Prepared candidate: POST /api/v1/loginViaBasic; basic-auth; 200. | Check POST /api/v1/loginViaBasic with Basic Auth and expected 200. Explain secret handling without values. | POST the login operation using Basic Auth only in the local client; predict 200 and hide the returned temporary token. | Accepted for the plan: the checker requires POST, basic-auth and 200 for this endpoint. | Pending: no live execution. Offline fields checked against the supplied validator; see validator_output.txt. |
| R4 | Not recorded before AI. Prepared candidate: POST /api/v1/books; x-api-key; 200. | Evaluate a generic 201 Created prediction for POST /api/v1/books against the supplied checker, which expects 200. Required fields are id, title, author. | Use POST, API-key authentication and Content-Type: application/json. Generic candidate: 201; corrected lab prediction: 200. | Modified: use 200 instead of the generic 201 candidate because EXPECTED["R4"] in the supplied checker requires 200. Runtime confirmation is still needed. | Pending: no live execution. Offline fields checked against the supplied validator; see validator_output.txt. |
| R5 | Not recorded before AI. Prepared candidate: GET /api/v1/books/{id}; none; 200. | Check GET /api/v1/books/{id}, no authentication, expected 200, after creating a fictional book. | Use the ID created in R4 as a path segment; predict 200 and compare returned book fields. | Accepted for the plan: the checker uses the variable path and none authentication; the actual ID belongs only in local evidence. | Pending: no live execution. Offline fields checked against the supplied validator; see validator_output.txt. |
| R6 | Not recorded before AI. Prepared candidate: DELETE /api/v1/books/{id}; x-api-key; 200. | Check DELETE /api/v1/books/{id}, API-key authentication, expected 200; explain safe cleanup. | Delete only the ID created for this activity using the local API key; predict 200. | Accepted for the plan: the checker requires x-api-key and 200; scope deletion to this activity’s own record. | Pending: no live execution. Offline fields checked against the supplied validator; see validator_output.txt. |
| R7 | Not recorded before AI. Prepared candidate: POST /api/v1/books; missing-or-invalid-key; 401. | Check POST /api/v1/books with the key omitted, expected 401. Explain the repair without providing any key. | Omit the key while keeping a valid JSON body; predict 401. Restore a valid local key; predict 200, verify the created book and clean it up. | Accepted for the plan: the checker requires missing-or-invalid-key and 401; the manual separately requires a successful repair. | Pending: no live execution. Offline fields checked against the supplied validator; see validator_output.txt. |

## Python script review

- Sanitized excerpt reviewed: unavailable. `add100RandomBooks.py` is referenced in the manual but is absent from the uploaded ZIP; no claim of reviewing its source is made.
- What the described script automates: the manual describes a bulk-add workflow that uses Requests for HTTP calls, JSON for book data, Faker for fictional values, authentication for protected POST requests, and a loop for repeated additions. Exact code, loop bounds, ID generation, and response parsing must be checked in the supplied VM script.
- AI recommendation evaluated: add a finite request timeout and validate the response before treating an insertion as successful.
- Decision and technical reason: accepted as a proposed improvement. A timeout limits waiting on a stalled request; checking the expected HTTP status prevents errors from being counted as successful inserts. Do not blindly retry a timed-out POST because the server may already have created the book.
- Independent validation performed: the request plan was checked with the original offline validator. This does not test the bulk script. The exact script review and its local test remain pending. See `PYTHON_SCRIPT_REVIEW.txt` for the conceptual review and local checks.

## AI-use disclosure

- Assistance received: ChatGPT filled the manual’s answer spaces, added the supplied name and section, drafted the request plan, evaluated design choices, prepared this log and a Postman collection, and ran the provided offline validator.
- Checks performed before accepting suggestions: compared the request plan with the manual’s explicit conventions and the checker’s EXPECTED mapping; confirmed 11/11 offline checks passed. These source-based checks are independent of the generated plan, but do not replace student review or live execution.
- Revisions made by the student: none were reported in this conversation. The student must personally review the answers, check the local documentation and record any subsequent changes.
- One limitation or error identified: the generic creation-status candidate of 201 does not match this lab’s required 200. Also, offline success cannot establish that the simulator accepted the request.
- Pre-AI checkpoint: cannot be recreated retroactively. The manual answers are explicitly AI-assisted; disclose this to the instructor if the checkpoint must have been completed before AI use.

## R7 diagnosis and repair plan

Use the same valid fictional JSON body after R6 has removed the original test record. Select No Auth and remove any manually supplied key header so the failure isolates authentication. Capture the actual 401 response with no secret values visible. Restore the valid local API key, resend the POST and capture the actual success. Verify the returned record by its ID, then delete that record. Record an unexpected result honestly and compare it with the local documentation before changing the plan.

## Source basis

- Attached IT0123 Module 4 manual, especially sections 6, 9, 10 and 11.
- Supplied `validate_request_plan.py`, EXPECTED and validation checks; file left unchanged.
- Supplied request-plan, validation-log and evidence-checklist templates.
